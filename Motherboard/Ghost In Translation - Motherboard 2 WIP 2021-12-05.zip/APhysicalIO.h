#ifndef APhysicalIO_h
#define APhysicalIO_h

#include "AIO.h"

class APhysicalIO : public AIO
{
public:
    APhysicalIO(int index, String name);
    byte getIndex();

protected:
    // The index starting at 0
    byte index = 0;
    
};

inline APhysicalIO::APhysicalIO(int index, String name):AIO{name}
{
  this->index = index;
}

inline byte APhysicalIO::getIndex()
{
    return this->index;
}

//#define APhysicalIO MotherboardNamespace::APhysicalIO

#endif
